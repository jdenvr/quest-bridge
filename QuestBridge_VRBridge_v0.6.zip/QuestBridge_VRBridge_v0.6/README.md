# QuestBridge v0.6 — Local PC/VR runtime bridge

## What changed, for real
This version implements an original **bidirectional UDP connection** between the Godot VR scene and QuestBridge's Python host. It can run in a desktop sample (WASD + mouse) or SteamVR sample (headset tracking + controllers, WASD with the Godot window focused). Godot sends live head position, controller positions and movement flags to Python. Python sends updated 3D object coordinates back. The golden sphere in the test scene is therefore positioned by **a different running process**, not just a local animation. No Refract or ADB.

**This is still NOT an Android Quest APK emulator. Imported APKs cannot be launched in either PC or VR mode yet.** The bridge supplies a transport mechanism for a future Android-XR guest; it does not provide an Android OS, ARM64 dynamic linker, mobile GPU rendering, VR API hooking, or Quest authentication. Do not mistake the test scene for the imported game.

## Quick start on Windows (Python 3.10+)
1. Unzip the project, then double-click **Open QuestBridge.bat**. It does not require SteamVR until you choose VR.
2. Open **Bridge Monitor** → **Test live UDP exchange**. This sends a real packet to a localhost server and checks the response. It does **not** need Godot, a headset, or a Quest APK.
3. Install [Godot 4.x for Windows](https://godotengine.org/download/windows/) (standard, not .NET). Put the Godot `.exe` in the same directory as **Open QuestBridge.bat** (or set `QUESTBRIDGE_GODOT`).
4. Open the **VR Lab** tab and select **Play PC sample — WASD**. Click into the 3D scene and walk around; return to the Bridge Monitor to see live position changes. The golden sphere should follow coordinates from Python.
5. For headset output, connect your Quest 3S using Steam Link or Quest Link, start SteamVR, select SteamVR as the OpenXR runtime, verify SteamVR sees your headset, and choose **Play VR sample — SteamVR**. You can move using WASD if the scene window has keyboard focus, while the headset and controllers track in VR.
6. **Import APK** still just inspects/stores the file. The two actual APK Play buttons stay disabled until a genuine executable Android-XR guest is integrated.

## Bridge protocol (v1)
- Transport: UDP, **localhost only** (`127.0.0.1`); ephemeral port allocated by OS.
- Host generates a temporary session token and passes it to Godot.
- Client sends JSON: `{ "v":1, "kind":"pose", "token":"...", "mode":"desktop|vr", "head":[x,y,z], "left":[x,y,z], "right":[x,y,z], "wasd":true, "fly":false, "noclip":false }`.
- Host responds with `{ "v":1, "kind":"world", "ball":[x,y,z], "frames":12 }`.
- No network sharing, game modification, or headset-data upload. The GUI displays latest pose and packet count.
- Future Android guests will require a distinct runtime adapter that translates the Android OpenXR/graphics calls to this host. The current server controls a demo object only.

## Testing
Run `python -m unittest discover -s tests -v` inside the project folder. Bridge tests exercise actual UDP packets on localhost, protocol parsing, and rejection of unauthenticated packets. Godot VR runtime and physical Quest 3S hardware must be verified on your Windows computer; they are **not** covered by Python tests.

## Project components
- `questbridge/bridge.py`: UDP tracking and world-state transport.
- `questbridge/vrtools.py`: on-demand desktop/SteamVR Godot launch and session connection.
- `godot_vr/scripts/Main.gd`: WASD, stereo OpenXR, tracker pose transmission, remote ball control.
- `questbridge/gui.py`: Library, VR Lab, Bridge Monitor, CPU Lab, Input Lab and honest runtime availability.
- `questbridge/apk.py`: read-only APK inspector.

## Next big development steps (not delivered in v0.6)
Android runtime / ARM64 native execution, Android lifecycle + Java libraries, Vulkan/OpenGL ES translation, Android OpenXR instance + action translation, Android frame-to-SteamVR texture interop, Meta platform compatibility testing, and finally a game launch compatibility matrix. Complex proprietary game requirements may still make certain APKs impossible to execute on PC.
