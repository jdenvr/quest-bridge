# QuestBridge VR Lab (Godot 4)

This is a native PC VR app built for Godot 4.3+ with **OpenXR + SteamVR**.
The project includes an original 3D arena, visible tracked controller blocks, and keyboard locomotion.
It is a **VR runtime proof of concept**, not an Android Quest APK execution system.

## Keys (focus game window)
- **WASD:** movement relative to headset facing (or desktop camera if no XR)
- **Shift:** sprint
- **F:** toggle flight
- **Space / Ctrl:** rise/descend when flying
- **N:** toggle noclip through test-world obstacles
- **Mouse:** desktop look only
- **Esc:** release desktop mouse
- **Enter or click:** recapture desktop mouse

Set SteamVR as the active OpenXR runtime in SteamVR Settings, connect Quest 3S through Steam Link, Quest Link or ALVR, open `project.godot` in Godot 4.3+ and Run (F6 or F5). If no XR runtime is active, a desktop 3D camera is used automatically.

**No Quest APK code is executed in this demo.** SteamVR shows only the test scene we created, not imported games.
