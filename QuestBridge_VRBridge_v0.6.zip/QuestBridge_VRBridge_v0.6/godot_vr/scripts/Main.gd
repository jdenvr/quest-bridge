extends Node3D
## QuestBridge VR Lab — native OpenXR demo; no imported APK code is executed.
## Keyboard WASD controls the virtual player's origin in desktop AND XR modes.

@onready var origin: XROrigin3D = $XROrigin3D
@onready var xr_camera: XRCamera3D = $XROrigin3D/XRCamera3D
@onready var desktop_camera: Camera3D = $XROrigin3D/DesktopCamera
@onready var left_hand: XRController3D = $XROrigin3D/LeftHand
@onready var right_hand: XRController3D = $XROrigin3D/RightHand

var xr_enabled: bool = false
var fly_enabled: bool = false
var noclip_enabled: bool = false
var sprint_speed: float = 11.0
var walking_speed: float = 4.0
var yaw_angle: float = 0.0
var pitch_angle: float = 0.0
var hud: Label3D
var input_hint: Label3D
var obstacles: Array[Vector4] = [] # x, z, half_width, half_depth
var orb: MeshInstance3D
var orb_time: float = 0.0
# Native UDP bridge: executable host code in Python, graphics in Godot.
# It transports real XR + WASD state; it does NOT execute an Android guest yet.
var qb_bridge: PacketPeerUDP = PacketPeerUDP.new()
var qb_bridge_active: bool = false
var qb_bridge_connected: bool = false
var qb_bridge_token: String = ""
var qb_bridge_timer: float = 0.0
var qb_bridge_last_frame: int = 0
var qb_bridge_last_received_ms: int = 0


func _ready() -> void:
    _build_world()
    _attach_controller_models()
    # Only touch OpenXR if VR mode was chosen in the Windows launcher.
    # Desktop launching uses --xr-mode off and must work without an HMD.
    var requested_vr: bool = "--qb-mode=vr" in OS.get_cmdline_user_args()
    xr_enabled = false
    if requested_vr:
        var xr_interface: XRInterface = XRServer.find_interface("OpenXR")
        if xr_interface != null and not xr_interface.is_initialized():
            xr_interface.initialize()
        xr_enabled = xr_interface != null and xr_interface.is_initialized()
        if not xr_enabled:
            push_warning("QuestBridge VR connection failed; starting desktop sample instead.")
    if xr_enabled:
        get_viewport().use_xr = true
        desktop_camera.current = false
        xr_camera.current = true
        DisplayServer.window_set_vsync_mode(DisplayServer.VSYNC_DISABLED)
        print("QUESTBRIDGE: OpenXR active — headset output enabled")
    else:
        get_viewport().use_xr = false
        desktop_camera.current = true
        Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
        print("QUESTBRIDGE: OpenXR unavailable — desktop WASD fallback active")
    _initialize_bridge()
    _update_labels()

func _unhandled_input(event: InputEvent) -> void:
    if event is InputEventKey and event.pressed and not event.echo:
        match event.physical_keycode:
            KEY_F:
                fly_enabled = not fly_enabled
                _update_labels()
            KEY_N:
                noclip_enabled = not noclip_enabled
                _update_labels()
            KEY_ESCAPE:
                Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
            KEY_ENTER:
                if not xr_enabled:
                    Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
    if event is InputEventMouseButton and event.pressed and not xr_enabled:
        Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
    if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
        if xr_enabled:
            # In VR, WASD direction follows your real head; mouse doesn't override tracking.
            return
        yaw_angle -= event.relative.x * 0.0025
        pitch_angle = clampf(pitch_angle - event.relative.y * 0.0025, -1.25, 1.25)
        origin.rotation.y = yaw_angle
        desktop_camera.rotation.x = pitch_angle

func _physics_process(delta: float) -> void:
    var horizontal := Vector2.ZERO
    if Input.is_physical_key_pressed(KEY_W): horizontal.y -= 1.0
    if Input.is_physical_key_pressed(KEY_S): horizontal.y += 1.0
    if Input.is_physical_key_pressed(KEY_A): horizontal.x -= 1.0
    if Input.is_physical_key_pressed(KEY_D): horizontal.x += 1.0
    var desired := Vector3.ZERO
    if horizontal.length() > 0.0:
        horizontal = horizontal.normalized()
        var view: Camera3D = xr_camera if xr_enabled else desktop_camera
        var forward: Vector3 = -view.global_basis.z
        var right: Vector3 = view.global_basis.x
        forward.y = 0.0
        right.y = 0.0
        forward = forward.normalized()
        right = right.normalized()
        desired = right * horizontal.x - forward * horizontal.y
    var current_speed: float = sprint_speed if Input.is_physical_key_pressed(KEY_SHIFT) else walking_speed
    var movement: Vector3 = desired * current_speed * delta
    if fly_enabled:
        if Input.is_physical_key_pressed(KEY_SPACE): movement.y += current_speed * delta
        if Input.is_physical_key_pressed(KEY_CTRL): movement.y -= current_speed * delta
    _apply_motion(movement)
    orb_time += delta
    if orb != null:
        if not qb_bridge_connected:
            orb.position.y = 1.6 + sin(orb_time * 1.8) * 0.25
        orb.rotate_y(delta * 1.4)
    _bridge_update(delta, horizontal.length() > 0.0)

func _apply_motion(motion: Vector3) -> void:
    var next_position: Vector3 = origin.position
    for axis in 3:
        var trial: Vector3 = next_position
        trial[axis] += motion[axis]
        trial.x = clampf(trial.x, -28.0, 28.0)
        trial.z = clampf(trial.z, -28.0, 28.0)
        trial.y = clampf(trial.y, -0.8, 12.0) if fly_enabled else 0.0
        if noclip_enabled or not _hits_wall(trial):
            next_position = trial
    origin.position = next_position

func _hits_wall(pos: Vector3) -> bool:
    # Manual collision for the deliberately simple test world, not game/APK physics.
    if pos.y > 2.5:
        return false
    for obstacle in obstacles:
        if absf(pos.x - obstacle.x) < obstacle.z + 0.42 and absf(pos.z - obstacle.y) < obstacle.w + 0.42:
            return true
    return false

func _update_labels() -> void:
    if hud != null:
        var mode: String = "HEADSET / STEAMVR" if xr_enabled else "DESKTOP"
        var link: String = "CONNECTED" if qb_bridge_connected else ("WAITING" if qb_bridge_active else "DISABLED")
        hud.text = "QUESTBRIDGE  VR LAB  v0.6\nMODE: %s | BRIDGE: %s\nWASD WALK  |  SHIFT SPRINT\nF FLY: %s   |  N NOCLIP: %s\nSPACE / CTRL ALTITUDE (FLY)\nESC UNLOCK MOUSE (DESKTOP)" % [mode, link, "ON" if fly_enabled else "OFF", "ON" if noclip_enabled else "OFF"]

func _initialize_bridge() -> void:
    var port: int = 0
    for arg in OS.get_cmdline_user_args():
        if arg.begins_with("--qb-bridge-port="):
            port = int(arg.trim_prefix("--qb-bridge-port="))
        elif arg.begins_with("--qb-bridge-token="):
            qb_bridge_token = arg.trim_prefix("--qb-bridge-token=")
    if port <= 0 or port > 65535 or qb_bridge_token.is_empty():
        print("QUESTBRIDGE: no host bridge configured")
        return
    var err: Error = qb_bridge.connect_to_host("127.0.0.1", port)
    if err != OK:
        push_warning("QuestBridge UDP host unavailable (code %s)" % err)
        return
    qb_bridge_active = true
    print("QUESTBRIDGE: tracking bridge configured on localhost:", port)

func _v3_array(point: Vector3) -> Array:
    return [snappedf(point.x, 0.001), snappedf(point.y, 0.001), snappedf(point.z, 0.001)]

func _bridge_update(delta: float, used_wasd: bool) -> void:
    if not qb_bridge_active:
        return
    if qb_bridge_connected and Time.get_ticks_msec() - qb_bridge_last_received_ms > 2000:
        qb_bridge_connected = false
        _update_labels()
    qb_bridge_timer += delta
    if qb_bridge_timer >= 0.075:
        qb_bridge_timer = 0.0
        var mode: String = "vr" if xr_enabled else "desktop"
        var camera: Camera3D = xr_camera if xr_enabled else desktop_camera
        var pose: Dictionary = {
            "v": 1, "kind": "pose", "token": qb_bridge_token, "mode": mode,
            "head": _v3_array(camera.global_position),
            "left": _v3_array(left_hand.global_position),
            "right": _v3_array(right_hand.global_position),
            "wasd": used_wasd, "fly": fly_enabled, "noclip": noclip_enabled
        }
        qb_bridge.put_packet(JSON.stringify(pose).to_utf8_buffer())
    while qb_bridge.get_available_packet_count() > 0:
        var response: Variant = JSON.parse_string(qb_bridge.get_packet().get_string_from_utf8())
        if not response is Dictionary:
            continue
        if response.get("kind", "") != "world" or response.get("v", 0) != 1:
            continue
        var ball: Variant = response.get("ball", [])
        if ball is Array and ball.size() == 3 and orb != null:
            orb.position = Vector3(float(ball[0]), float(ball[1]), float(ball[2]))
            qb_bridge_connected = true
            qb_bridge_last_frame = int(response.get("frames", 0))
            qb_bridge_last_received_ms = Time.get_ticks_msec()
            _update_labels()

func _build_world() -> void:
    var environment := Environment.new()
    environment.background_mode = Environment.BG_COLOR
    environment.background_color = Color("07121d")
    environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    environment.ambient_light_color = Color("8dbed3")
    environment.ambient_light_energy = 0.6
    $WorldEnvironment.environment = environment
    _make_box(Vector3(0.0, -0.12, 0.0), Vector3(60, 0.18, 60), Color("122739"))
    # Gridded floor for comfortable depth and scale perception in VR.
    for i in range(-29, 30, 2):
        _make_box(Vector3(float(i), -0.018, 0), Vector3(0.016, 0.007, 59), Color("245b69"), false)
        _make_box(Vector3(0, -0.017, float(i)), Vector3(59, 0.007, 0.016), Color("245b69"), false)
    _make_box(Vector3(0, 0.04, 0), Vector3(2.8, 0.09, 2.8), Color("145e6e"), false)
    # Intentionally small collision maze — N can toggle true wall pass-through.
    _add_obstacle(-4.0, -4.0, 1.3, 1.3, 3.3, Color("6c509d"))
    _add_obstacle(4.3, -3.0, 1.2, 1.2, 2.8, Color("276b88"))
    _add_obstacle(-5.0, 3.0, 1.0, 2.2, 2.5, Color("367965"))
    _add_obstacle(6.0, 4.0, 2.1, 0.7, 3.8, Color("6c509d"))
    _add_obstacle(0.5, -11.0, 3.0, 0.7, 2.8, Color("28757a"))
    _add_obstacle(-10.0, 0.0, 1.0, 4.0, 2.8, Color("6c509d"))
    _add_obstacle(12.0, -9.0, 0.9, 2.5, 4.0, Color("367965"))
    _add_obstacle(10.0, 11.0, 2.5, 0.9, 2.7, Color("276b88"))
    var sunlight := DirectionalLight3D.new()
    sunlight.rotation_degrees = Vector3(-48, -30, 0)
    sunlight.light_color = Color("b8e9ff")
    sunlight.light_energy = 1.1
    add_child(sunlight)
    orb = _make_sphere(Vector3(0, 1.6, -7.5), 0.65, Color("f5b865"))
    hud = _make_text(Vector3(-2.7, 3.0, -6.0), "", Color("d7fffc"), 36)
    input_hint = _make_text(Vector3(3.0, 2.4, -7.0), "LIVE TRACKING → PYTHON HOST\nPYTHON HOST → SCENE ORB\nAPK EXECUTION REQUIRES ANDROID XR", Color("f8ca99"), 23)

func _make_box(pos: Vector3, size: Vector3, color: Color, shade: bool = true) -> MeshInstance3D:
    var node := MeshInstance3D.new()
    var mesh := BoxMesh.new()
    mesh.size = size
    node.mesh = mesh
    node.position = pos
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    mat.metallic = 0.1
    mat.roughness = 0.7
    if not shade:
        mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    node.material_override = mat
    add_child(node)
    return node

func _make_sphere(pos: Vector3, radius: float, color: Color) -> MeshInstance3D:
    var node := MeshInstance3D.new()
    var mesh := SphereMesh.new()
    mesh.radius = radius
    mesh.height = 2.0 * radius
    node.mesh = mesh
    node.position = pos
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    mat.emission_enabled = true
    mat.emission = color * 0.5
    node.material_override = mat
    add_child(node)
    return node

func _make_text(pos: Vector3, words: String, color: Color, font_size: int) -> Label3D:
    var node := Label3D.new()
    node.position = pos
    node.text = words
    node.font_size = font_size
    node.pixel_size = 0.0035
    node.modulate = color
    node.outline_modulate = Color("06101b")
    node.outline_size = 6
    node.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    add_child(node)
    return node

func _add_obstacle(x: float, z: float, half_x: float, half_z: float, height: float, color: Color) -> void:
    _make_box(Vector3(x, height / 2.0, z), Vector3(half_x * 2.0, height, half_z * 2.0), color)
    obstacles.append(Vector4(x, z, half_x, half_z))

func _attach_controller_models() -> void:
    # Actual positions are driven by OpenXR trackers, not keyboard emulation.
    _attach_hand(left_hand, Color("6ee5d2"))
    _attach_hand(right_hand, Color("f6b95f"))

func _attach_hand(controller: XRController3D, color: Color) -> void:
    var node := MeshInstance3D.new()
    var mesh := BoxMesh.new()
    mesh.size = Vector3(0.09, 0.16, 0.22)
    node.mesh = mesh
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    node.material_override = mat
    controller.add_child(node)
