import os
import sys
import unittest
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch, MagicMock

from questbridge import vrtools


class VRToolsTests(unittest.TestCase):
    def test_scene_files_exist(self):
        self.assertTrue((vrtools.GODOT_PROJECT / 'project.godot').is_file())
        self.assertTrue((vrtools.GODOT_PROJECT / 'Main.tscn').is_file())
        script = (vrtools.GODOT_PROJECT / 'scripts' / 'Main.gd').read_text()
        for required in ('XRServer.find_interface("OpenXR")', 'Input.is_physical_key_pressed(KEY_W)',
                         'get_viewport().use_xr = true', 'XROrigin3D', 'noclip_enabled'):
            self.assertIn(required, script)

    def test_launch_builds_real_native_vr_command_not_apk(self):
        with TemporaryDirectory() as tmp:
            fake_godot = Path(tmp) / 'Godot_v4.5-stable_win64.exe'
            fake_godot.write_bytes(b'dummy')
            with patch.object(vrtools.subprocess, 'Popen') as popen:
                popen.return_value = MagicMock(pid=123)
                vrtools.launch_vr_lab(fake_godot)
                actual = popen.call_args.args[0]
                self.assertEqual(actual[0], str(fake_godot))
                self.assertEqual(actual[1:3], ['--path', str(vrtools.GODOT_PROJECT)])
                self.assertIn('--xr-mode', actual)
                self.assertIn('off', actual)
                self.assertIn('--qb-mode=desktop', actual)
                self.assertNotIn('.apk', ' '.join(actual))

    def test_vr_flag_only_when_user_chooses_vr(self):
        with TemporaryDirectory() as tmp:
            fake_godot = Path(tmp) / 'Godot.exe'
            fake_godot.write_bytes(b'fixture')
            with patch.object(vrtools.subprocess, 'Popen') as popen:
                popen.return_value = MagicMock(pid=12)
                vrtools.launch_vr_lab(fake_godot, mode='vr')
                cmd = popen.call_args.args[0]
                self.assertIn('on', cmd)
                self.assertIn('--qb-mode=vr', cmd)

    def test_host_bridge_cli_arguments(self):
        with TemporaryDirectory() as tmp:
            fake = Path(tmp) / 'godot.exe'
            fake.write_bytes(b'test')
            with patch.object(vrtools.subprocess, 'Popen') as popen:
                popen.return_value = MagicMock(pid=77)
                vrtools.launch_vr_lab(fake, mode='vr', bridge_port=33333, bridge_token='token-sample')
                args = popen.call_args.args[0]
                self.assertIn('--qb-bridge-port=33333', args)
                self.assertIn('--qb-bridge-token=token-sample', args)
                self.assertIn('--qb-mode=vr', args)

    def test_rejects_bad_mode(self):
        with self.assertRaises(ValueError):
            vrtools.launch_vr_lab(mode='invalid')

    def test_godot_path_override(self):
        with TemporaryDirectory() as tmp:
            target = Path(tmp) / 'godot.exe'
            target.write_bytes(b'dummy')
            with patch.dict(os.environ, {'QUESTBRIDGE_GODOT': str(target)}):
                self.assertEqual(vrtools.find_godot(), target)

    def test_missing_engine_reports_error(self):
        with patch.object(vrtools, 'find_godot', return_value=None):
            with self.assertRaises(FileNotFoundError):
                vrtools.launch_vr_lab()

    def test_desktop_no_windows_registry_claim(self):
        if sys.platform != 'win32':
            self.assertIn('Windows', vrtools.vr_runtime_summary())

if __name__ == '__main__':
    unittest.main()
