import tempfile
import unittest
import zipfile
from pathlib import Path
from questbridge.arm64 import Machine, ExecutionError, demo_trace, sample_program
from questbridge.apk import analyze_apk
from questbridge.storage import Store

class NativeTests(unittest.TestCase):
    def test_cpu_demo(self):
        result=demo_trace()
        self.assertEqual((result['x0'],result['x1'],result['steps']),(12,3,5))
    def test_unsupported_opcode(self):
        with self.assertRaises(ExecutionError):Machine(b'\xff\xff\xff\xff').run()
    def test_no_infinite_loop(self):
        with self.assertRaises(ExecutionError):Machine((0x14000000).to_bytes(4,'little'),limit=10).run()
    def test_branch(self):
        import struct
        program=struct.pack('<III',0x14000002,0xd2800000 | (99<<5),0xd65f03c0)
        result=Machine(program).run()
        self.assertEqual(result.get(0),0)
    def test_wrong_stream_alignment(self):
        with self.assertRaises(ValueError):Machine(b'a')
    def test_sample_decoding(self):
        self.assertEqual(len(sample_program()),20)
    def test_apk_import(self):
        with tempfile.TemporaryDirectory() as d:
            apk=Path(d)/'test.apk'
            with zipfile.ZipFile(apk,'w') as z:
                z.writestr('AndroidManifest.xml', '<manifest package="org.questbridge.sample"></manifest>')
                z.writestr('lib/arm64-v8a/libexample.so',b'not executable')
            info=analyze_apk(apk)
            self.assertEqual(info.package,'org.questbridge.sample')
            self.assertIn('arm64-v8a',info.abis)
            store=Store(Path(d)/'data')
            rec=store.import_apk(apk)
            self.assertTrue(Path(rec['path']).exists())
            self.assertEqual(len(store.data['games']),1)
            store.remove(rec['id'])
            self.assertEqual(len(store.data['games']),0)

if __name__=='__main__':unittest.main()
