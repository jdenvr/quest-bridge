import json
import socket
import time
import unittest

from questbridge.bridge import BridgeServer, decode_pose, probe_bridge, MAX_PACKET


class TestBridge(unittest.TestCase):
    def test_parse_real_pose(self):
        packet={'v':1,'kind':'pose','mode':'vr', 'head':[1,2,3], 'left':[1,1,1],
                'right':[2,2,2],'wasd':True}
        self.assertEqual(decode_pose(json.dumps(packet).encode())['head'], [1.,2.,3.])

    def test_reject_bad_pose(self):
        cases=[{'v':1,'kind':'pose','mode':'vr','head':[0,0,float('nan')], 'left':[0,0,0], 'right':[0,0,0]},
               {'v':1,'kind':'pose','mode':'else'},
               {'v':2,'kind':'pose','mode':'vr'},
               {'v':1,'kind':'world','mode':'vr'}]
        for case in cases:
            with self.assertRaises(ValueError):
                decode_pose(json.dumps(case).encode())
        with self.assertRaises(ValueError):
            decode_pose(b'x'*(MAX_PACKET+1))

    def test_loopback_real_udp(self):
        host=BridgeServer().start()
        try:
            result=probe_bridge(host)
            self.assertEqual(result['kind'], 'world')
            self.assertEqual(len(result['ball']),3)
            snap=host.snapshot()
            self.assertTrue(snap.running)
            self.assertTrue(snap.connected)
            self.assertEqual(snap.mode,'desktop')
            self.assertEqual(snap.frames,1)
        finally:
            host.close()
        self.assertFalse(host.snapshot().running)

    def test_token_required(self):
        host=BridgeServer().start()
        try:
            with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as client:
                client.settimeout(.2)
                client.sendto(json.dumps({'v':1,'kind':'pose','mode':'desktop','token':'not-valid',
                    'head':[0,0,0],'left':[0,0,0],'right':[0,0,0]}).encode(),
                    ('127.0.0.1',host.port))
                with self.assertRaises(socket.timeout):
                    client.recvfrom(2048)
            self.assertEqual(host.snapshot().frames,0)
        finally:
            host.close()

if __name__ == '__main__':unittest.main()
