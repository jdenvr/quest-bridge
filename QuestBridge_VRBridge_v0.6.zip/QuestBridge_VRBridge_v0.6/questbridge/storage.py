"""Local library and settings. Files stay on the user's PC."""
from __future__ import annotations
import json
import os
from pathlib import Path
import shutil
from datetime import datetime, timezone
from .apk import analyze_apk


def default_home() -> Path:
    base = os.getenv('LOCALAPPDATA') or str(Path.home() / '.local' / 'share')
    return Path(base) / 'QuestBridgeNative'


class Store:
    def __init__(self, home: Path | None = None):
        self.home = Path(home) if home else default_home()
        self.home.mkdir(parents=True, exist_ok=True)
        self.apks = self.home / 'apks'
        self.apks.mkdir(exist_ok=True)
        self.data_file = self.home / 'library.json'
        self.data = {'games': [], 'settings': {}}
        if self.data_file.exists():
            try:
                read = json.loads(self.data_file.read_text(encoding='utf-8'))
                if isinstance(read.get('games'), list) and isinstance(read.get('settings'), dict):
                    self.data = read
            except (json.JSONDecodeError, OSError, AttributeError):
                pass

    def save(self):
        temp = self.data_file.with_suffix('.tmp')
        temp.write_text(json.dumps(self.data, indent=2), encoding='utf-8')
        temp.replace(self.data_file)

    def import_apk(self, file_path):
        info = analyze_apk(file_path)
        dest = self.apks / f'{info.sha256[:16]}.apk'
        if not dest.exists():
            shutil.copy2(file_path, dest)
        record = info.as_dict()
        record.update({'id': info.sha256[:16], 'path': str(dest),
                       'imported_at': datetime.now(timezone.utc).isoformat()})
        games = self.data['games']
        games[:] = [g for g in games if g.get('id') != record['id']]
        games.insert(0, record)
        self.save()
        return record

    def remove(self, game_id):
        games = self.data['games']
        found = next((g for g in games if g.get('id') == game_id), None)
        if not found:
            return False
        target = Path(found['path'])
        # Never delete outside our managed APK folder.
        if target.parent.resolve() == self.apks.resolve() and target.exists():
            target.unlink()
        games[:] = [g for g in games if g.get('id') != game_id]
        self.save()
        return True

    def settings(self):
        return self.data['settings']

    def set_setting(self, name, value):
        self.data['settings'][name] = str(value)
        self.save()
