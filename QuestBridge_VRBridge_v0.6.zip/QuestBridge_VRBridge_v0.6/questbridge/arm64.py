"""Original, tiny AArch64 instruction interpreter (education/proof of concept).

This is NOT an Android emulator: it only executes a few arithmetic/branch
instructions from a controlled in-memory sample. No ELF loader, syscalls,
MMU, floating point/SIMD, threads, or dynamic linking are implemented.
"""
from __future__ import annotations
from dataclasses import dataclass, field
import struct

MASK64 = (1 << 64) - 1

class ExecutionError(Exception):
    pass

@dataclass
class Machine:
    code: bytes
    registers: list[int] = field(default_factory=lambda: [0] * 31)
    pc: int = 0
    halted: bool = False
    trace: list[str] = field(default_factory=list)
    limit: int = 10_000
    count: int = 0

    def __post_init__(self):
        if len(self.code) % 4:
            raise ValueError('Instruction stream must be 4-byte aligned')

    def get(self, reg: int) -> int:
        return self.registers[reg] if reg < 31 else 0

    def set(self, reg: int, value: int):
        if reg < 31:
            self.registers[reg] = value & MASK64

    def step(self):
        if self.halted:
            return
        if self.count >= self.limit:
            raise ExecutionError(f'Step limit reached ({self.limit})')
        if self.pc % 4 or self.pc < 0 or self.pc + 4 > len(self.code):
            raise ExecutionError(f'PC outside code: 0x{self.pc:x}')
        address = self.pc
        instr = struct.unpack_from('<I', self.code, self.pc)[0]
        self.pc += 4
        self.count += 1

        if (instr & 0xff800000) == 0xd2800000:   # MOVZ Xd, #imm16, LSL #0/16/32/48
            rd = instr & 31
            imm16 = (instr >> 5) & 0xffff
            shift = ((instr >> 21) & 3) * 16
            value = imm16 << shift
            self.set(rd, value)
            op = f'MOVZ X{rd}, #{imm16}, LSL #{shift}'
        elif (instr & 0xffc00000) == 0x91000000: # ADD Xd, Xn, #imm12
            rd, rn = instr & 31, (instr >> 5) & 31
            imm = (instr >> 10) & 0xfff
            self.set(rd, self.get(rn) + imm)
            op = f'ADD X{rd}, X{rn}, #{imm}'
        elif (instr & 0xffc00000) == 0xd1000000: # SUB Xd, Xn, #imm12
            rd, rn = instr & 31, (instr >> 5) & 31
            imm = (instr >> 10) & 0xfff
            self.set(rd, self.get(rn) - imm)
            op = f'SUB X{rd}, X{rn}, #{imm}'
        elif (instr & 0xfc000000) == 0x14000000: # B #signed_imm26 * 4
            imm = instr & 0x03ffffff
            if imm & (1 << 25):
                imm -= 1 << 26
            self.pc = address + imm * 4
            op = f'B 0x{self.pc:x}'
        elif instr == 0xd503201f:                # NOP
            op = 'NOP'
        elif (instr & 0xfffffc1f) == 0xd65f0000: # RET Xn -- halts synthetic program
            self.halted = True
            op = 'RET (stop)'
        else:
            raise ExecutionError(f'Unsupported AArch64 opcode 0x{instr:08x} at PC=0x{address:x}')
        self.trace.append(f'0x{address:04x}  {instr:08x}   {op}')

    def run(self):
        while not self.halted:
            self.step()
        return self


def sample_program() -> bytes:
    #  MOVZ X0,#7 ; MOVZ X1,#5 ; ADD X0,X0,#5 ; SUB X1,X1,#2 ; RET
    instructions = [
        0xd2800000 | (7 << 5),
        0xd2800001 | (5 << 5),
        0x91000000 | (5 << 10) | (0 << 5) | 0,
        0xd1000000 | (2 << 10) | (1 << 5) | 1,
        0xd65f03c0,
    ]
    return struct.pack('<' + 'I' * len(instructions), *instructions)


def demo_trace():
    machine = Machine(sample_program()).run()
    return {'x0': machine.registers[0], 'x1': machine.registers[1],
            'steps': machine.count, 'trace': machine.trace}
