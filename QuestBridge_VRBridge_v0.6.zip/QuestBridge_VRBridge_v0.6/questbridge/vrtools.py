"""Native QuestBridge VR scene launch support; no emulator backend or APK execution."""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import os
import shutil
import subprocess
import sys


PROJECT_ROOT = Path(__file__).resolve().parents[1]
GODOT_PROJECT = PROJECT_ROOT / 'godot_vr'


def _is_executable_file(path: Path) -> bool:
    return path.is_file() and path.suffix.lower() in ('.exe', '')


def find_godot() -> Path | None:
    """Look for user-supplied Godot path, local portable file, then PATH."""
    candidates: list[Path] = []
    explicit = os.environ.get('QUESTBRIDGE_GODOT')
    if explicit:
        candidates.append(Path(explicit))
    for folder in (PROJECT_ROOT, Path.home() / 'Downloads', Path.home() / 'Desktop'):
        if folder.is_dir():
            for pattern in ('godot.exe', 'Godot.exe', 'Godot_v4*.exe', 'Godot_v4*.x86_64'):
                candidates.extend(folder.glob(pattern))
    for name in ('godot', 'godot4', 'godot.exe', 'godot4.exe'):
        command = shutil.which(name)
        if command:
            candidates.append(Path(command))
    for path in candidates:
        if _is_executable_file(path):
            return path
    return None


def vr_runtime_summary() -> str:
    """Read-only Windows active OpenXR runtime registry query (if available)."""
    if sys.platform != 'win32':
        return 'OpenXR runtime check requires Windows; desktop demo can be tested separately.'
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r'SOFTWARE\Khronos\OpenXR\1') as key:
            raw = winreg.QueryValueEx(key, 'ActiveRuntime')[0]
            return f'Active OpenXR runtime: {raw}'
    except (OSError, ImportError):
        return 'No active OpenXR runtime detected in Windows registry.'


def launch_vr_lab(godot: Path | None = None, mode: str = 'desktop', bridge_port: int | None = None, bridge_token: str | None = None):
    """Launch our own native sample in desktop or VR mode, never imported APKs.

    Crucially, `desktop` disables OpenXR at process startup; library UI runs
    independently and should NEVER initialize OpenXR.
    """
    if mode not in ('desktop', 'vr'):
        raise ValueError('Mode must be desktop or vr')
    if godot is None:
        godot = find_godot()
    if not godot:
        raise FileNotFoundError('Godot 4.3+ is not installed or not found. Install or put its EXE beside QuestBridge.')
    if not (GODOT_PROJECT / 'project.godot').is_file():
        raise FileNotFoundError('The QuestBridge VR Lab project is missing.')
    args = [str(godot), '--path', str(GODOT_PROJECT), '--xr-mode', 'on' if mode == 'vr' else 'off', '--', f'--qb-mode={mode}']
    if bridge_port is not None:
        if not (1 <= bridge_port <= 65535) or not bridge_token:
            raise ValueError('Bridge port and authentication token required')
        args.extend([f'--qb-bridge-port={bridge_port}', f'--qb-bridge-token={bridge_token}'])
    return subprocess.Popen(args, cwd=str(GODOT_PROJECT))
