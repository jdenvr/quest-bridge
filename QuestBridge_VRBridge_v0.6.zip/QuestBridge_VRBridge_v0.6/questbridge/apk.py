"""Read-only APK archive inspection. Never executes APK contents."""
from __future__ import annotations
from dataclasses import dataclass, asdict
from pathlib import Path
import hashlib
import struct
import zipfile

MAX_ARCHIVE_ENTRIES = 120_000


def _u16(b: bytes, pos: int) -> int:
    return struct.unpack_from('<H', b, pos)[0]


def _u32(b: bytes, pos: int) -> int:
    return struct.unpack_from('<I', b, pos)[0]


def _length8(data: bytes, pos: int):
    n = data[pos]
    if n & 0x80:
        return ((n & 0x7f) << 8) | data[pos + 1], pos + 2
    return n, pos + 1


def _length16(data: bytes, pos: int):
    n = _u16(data, pos)
    if n & 0x8000:
        return ((n & 0x7fff) << 16) | _u16(data, pos + 2), pos + 4
    return n, pos + 2


def android_manifest_package(raw: bytes) -> str | None:
    """Decode package in Android's binary XML format (or a test XML manifest)."""
    if raw.lstrip().startswith(b'<'):
        import re
        m = re.search(rb'<manifest\b[^>]*\bpackage\s*=\s*[\"\']([^\"\']+)', raw)
        return m.group(1).decode('utf-8', errors='replace') if m else None
    try:
        if len(raw) < 8 or _u16(raw, 0) != 0x0003:
            return None
        cursor = _u16(raw, 2)
        strings: list[str] = []
        while cursor + 8 <= len(raw):
            kind = _u16(raw, cursor)
            header_size = _u16(raw, cursor + 2)
            size = _u32(raw, cursor + 4)
            if size < header_size or size < 8 or cursor + size > len(raw):
                break
            if kind == 0x0001:  # string pool
                count = _u32(raw, cursor + 8)
                flags = _u32(raw, cursor + 16)
                string_start = _u32(raw, cursor + 20)
                if count > 100_000:
                    return None
                utf8 = bool(flags & 0x100)
                for i in range(count):
                    offset = _u32(raw, cursor + header_size + 4 * i)
                    pos = cursor + string_start + offset
                    if utf8:
                        _, pos = _length8(raw, pos)
                        byte_count, pos = _length8(raw, pos)
                        value = raw[pos:pos + byte_count].decode('utf-8', errors='replace')
                    else:
                        char_count, pos = _length16(raw, pos)
                        value = raw[pos:pos + char_count * 2].decode('utf-16le', errors='replace')
                    strings.append(value)
            elif kind == 0x0102 and strings:  # start element
                name_id = _u32(raw, cursor + 20)
                if name_id < len(strings) and strings[name_id] == 'manifest':
                    attr_start = _u16(raw, cursor + 24)
                    attr_size = _u16(raw, cursor + 26)
                    attr_count = _u16(raw, cursor + 28)
                    base = cursor + 16 + attr_start
                    for i in range(min(attr_count, 512)):
                        p = base + i * attr_size
                        if attr_size < 20 or p + 20 > cursor + size:
                            break
                        key_id = _u32(raw, p + 4)
                        if key_id < len(strings) and strings[key_id] == 'package':
                            raw_id = _u32(raw, p + 8)
                            if raw_id < len(strings):
                                return strings[raw_id]
                            if raw[p + 15] == 0x03:
                                val_id = _u32(raw, p + 16)
                                if val_id < len(strings):
                                    return strings[val_id]
            cursor += size
    except (IndexError, struct.error, ValueError, UnicodeError):
        return None
    return None


@dataclass
class APKInfo:
    name: str
    bytes: int
    sha256: str
    package: str | None
    abis: list[str]
    engine: str
    native_libraries: int
    files: int
    has_obb: bool
    potential_openxr: bool
    notes: list[str]

    def as_dict(self):
        return asdict(self)


def analyze_apk(path: str | Path) -> APKInfo:
    source = Path(path)
    if not source.is_file() or source.suffix.lower() != '.apk':
        raise ValueError('Choose a valid .apk file.')
    if not zipfile.is_zipfile(source):
        raise ValueError('APK is not a readable ZIP archive.')
    sha = hashlib.sha256()
    with source.open('rb') as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b''):
            sha.update(chunk)
    with zipfile.ZipFile(source) as z:
        names = z.namelist()
        if len(names) > MAX_ARCHIVE_ENTRIES:
            raise ValueError('APK has an unusually large file table; refusing to inspect.')
        lower = [n.lower() for n in names]
        native_libs = [n for n in names if n.startswith('lib/') and n.endswith('.so')]
        abis = sorted({n.split('/')[1] for n in native_libs if len(n.split('/')) >= 3})
        package = None
        if 'AndroidManifest.xml' in names:
            manifest_info = z.getinfo('AndroidManifest.xml')
            if manifest_info.file_size <= 10 * 1024 * 1024:
                package = android_manifest_package(z.read('AndroidManifest.xml'))
        engine = 'Unknown'
        if any('libunity.so' in n or 'libil2cpp.so' in n for n in lower):
            engine = 'Unity (inferred)'
        elif any(n.endswith(('libue4.so', 'libunreal.so')) for n in lower):
            engine = 'Unreal (inferred)'
        xr = any('openxr' in n or 'oculus' in n for n in lower)
        notes = []
        if 'arm64-v8a' in abis and 'x86_64' not in abis:
            notes.append('ARM64-only native code: an x86 PC Android emulator needs ARM translation.')
        if not package:
            notes.append('Package name not decoded; install/launch requires an Android SDK aapt tool or a compatible manifest.')
        if not xr:
            notes.append('No obvious XR marker in archive filenames; this does not prove the APK lacks XR support.')
        notes.append('Quest platform services and multiplayer compatibility cannot be determined from APK structure alone.')
        return APKInfo(source.name, source.stat().st_size, sha.hexdigest(), package,
                       abis, engine, len(native_libs), len(names),
                       any(n.endswith('.obb') for n in lower), xr, notes)
