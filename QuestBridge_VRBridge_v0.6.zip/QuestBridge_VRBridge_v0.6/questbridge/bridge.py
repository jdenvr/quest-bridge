"""QuestBridge's real local-process tracking/scene-data transport.

Protocol version 1: UDP on 127.0.0.1, one Godot process per bridge. This
transports pose + WASD locomotion state, NOT Android APK execution.
"""
from __future__ import annotations
from dataclasses import dataclass
import json
import math
import secrets
import socket
import threading
import time
from typing import Any

MAX_PACKET = 4096
MAX_TELEMETRY_HZ = 90


def _vec3(raw: Any) -> list[float]:
    if not isinstance(raw, list) or len(raw) != 3:
        raise ValueError('Expected 3D vector')
    values = [float(x) for x in raw]
    if not all(math.isfinite(x) and abs(x) < 100_000 for x in values):
        raise ValueError('Invalid coordinate')
    return values


def decode_pose(raw: bytes) -> dict:
    if len(raw) > MAX_PACKET:
        raise ValueError('Packet too large')
    payload = json.loads(raw.decode('utf-8'))
    if not isinstance(payload, dict) or payload.get('v') != 1 or payload.get('kind') != 'pose':
        raise ValueError('Unexpected protocol message')
    mode = payload.get('mode')
    if mode not in ('vr', 'desktop'):
        raise ValueError('Unknown runtime mode')
    return {
        'kind': 'pose', 'mode': mode,
        'head': _vec3(payload.get('head')),
        'left': _vec3(payload.get('left')),
        'right': _vec3(payload.get('right')),
        'wasd': bool(payload.get('wasd', False)),
        'fly': bool(payload.get('fly', False)),
        'noclip': bool(payload.get('noclip', False)),
    }


@dataclass(frozen=True)
class BridgeSnapshot:
    running: bool
    connected: bool
    port: int
    frames: int
    mode: str
    head: tuple[float, float, float]
    has_wasd: bool
    age_seconds: float | None
    last_error: str


class BridgeServer:
    """Send a moving, server-authored sample object to native Godot VR.

    A later Android guest adapter can consume pose packets and provide world
    state; no claims are made about Android app compatibility today.
    """
    def __init__(self, port: int = 0):
        self._lock = threading.Lock()
        self._socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self._socket.bind(('127.0.0.1', port))
        self._socket.settimeout(0.25)
        self.port = self._socket.getsockname()[1]
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._frames = 0
        self._mode = 'none'
        self._head = (0.0, 0.0, 0.0)
        self._wasd = False
        self._seen = 0.0
        self._error = ''
        self._token = secrets.token_hex(12)

    @property
    def token(self) -> str:
        return self._token

    def start(self) -> 'BridgeServer':
        if self._thread is None:
            self._thread = threading.Thread(target=self._loop, name='QuestBridgeUDP', daemon=True)
            self._thread.start()
        return self

    def _loop(self):
        while not self._stop.is_set():
            try:
                raw, address = self._socket.recvfrom(MAX_PACKET + 1)
            except socket.timeout:
                continue
            except OSError:
                break
            try:
                # Prevent unrelated local processes from spoofing scene state.
                packet = json.loads(raw.decode('utf-8'))
                if packet.get('token') != self._token:
                    continue
                pose = decode_pose(raw)
                now = time.monotonic()
                with self._lock:
                    self._frames += 1
                    self._seen = now
                    self._mode = pose['mode']
                    self._head = tuple(pose['head'])
                    self._wasd = pose['wasd']
                    self._error = ''
                # Physics proof: the Python host owns this sphere's orbit; the
                # Godot renderer simply displays updates received over UDP.
                elapsed = now
                ball = [round(2.2 * math.sin(elapsed * 0.7), 3),
                        round(1.4 + 0.45 * math.sin(elapsed * 1.2), 3),
                        round(-7.0 + 1.7 * math.cos(elapsed * 0.7), 3)]
                response = {'v': 1, 'kind': 'world', 'ball': ball, 'frames': self._frames}
                self._socket.sendto(json.dumps(response, separators=(',', ':')).encode('utf-8'), address)
            except (ValueError, TypeError, UnicodeError, json.JSONDecodeError, OverflowError) as e:
                with self._lock:
                    self._error = f'Invalid packet: {str(e)[:120]}'
            except OSError:
                if not self._stop.is_set():
                    break

    def snapshot(self) -> BridgeSnapshot:
        with self._lock:
            age = time.monotonic() - self._seen if self._seen else None
            return BridgeSnapshot(
                running=not self._stop.is_set() and self._thread is not None and self._thread.is_alive(),
                connected=age is not None and age < 2.0,
                port=self.port, frames=self._frames,
                mode=self._mode, head=self._head,
                has_wasd=self._wasd, age_seconds=age, last_error=self._error,
            )

    def close(self):
        self._stop.set()
        self._socket.close()
        if self._thread is not None:
            self._thread.join(timeout=1.0)


def probe_bridge(server: BridgeServer, mode: str = 'desktop') -> dict:
    """Exercise the *real UDP socket* without installing Godot or a headset."""
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as client:
        client.settimeout(2.0)
        packet = {'v': 1, 'kind': 'pose', 'mode': mode, 'token': server.token,
                  'head': [0, 1.7, 0], 'left': [-.2, 1.2, -.4],
                  'right': [.2, 1.2, -.4], 'wasd': True, 'fly': False, 'noclip': False}
        client.sendto(json.dumps(packet).encode('utf-8'), ('127.0.0.1', server.port))
        data, _ = client.recvfrom(MAX_PACKET)
        result = json.loads(data)
        if result.get('kind') != 'world' or len(result.get('ball', [])) != 3:
            raise ValueError('Bridge did not answer with world state')
        return result
