"""QuestBridge Native Windows GUI: original, local APK laboratory.

No third-party launcher or runtime. Nothing here executes real APK contents.
"""
from __future__ import annotations
import json
import math
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from pathlib import Path
from .storage import Store
from .arm64 import demo_trace
from .vrtools import find_godot, vr_runtime_summary, launch_vr_lab
from .bridge import BridgeServer, probe_bridge

DARK='#0b1020'; SIDE='#111a2b'; PANEL='#172237'; PANEL2='#21324d'
INK='#ecf2fb'; MUTED='#9fb1ca'; TEAL='#77e1cd'; GOLD='#e7bf7f'; BAD='#fa8392'

class QuestBridge(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title('QuestBridge — VR Bridge & APK Research v0.6')
        self.geometry('1080x720')
        self.minsize(820, 610)
        self.configure(bg=DARK)
        self.store=Store()
        self.bridge: BridgeServer | None = None
        self.bridge_monitor = None
        self.protocol('WM_DELETE_WINDOW', self._close)
        self.page=''
        self.selected=None
        self.held=set()
        self.fly=False; self.noclip=False
        self.pos=[210.,210.]; self.ball=[360.,180.]
        self.canvas=None
        self.status=tk.StringVar(value='Ready • Import APKs or launch the PC/VR sample • No XR required to open QuestBridge')
        self._shell()
        self.bind_all('<KeyPress>',self._press)
        self.bind_all('<KeyRelease>',self._release)
        self.show('Library')
        self.after(40,self._tick)

    def label(self,where,text,sz=11,color=INK,bold=False,**kw):
        return tk.Label(where,text=text,font=('Segoe UI',sz,'bold' if bold else 'normal'),
                        fg=color,bg=where.cget('bg'),**kw)

    def button(self,where,text,fn,accent=False):
        return tk.Button(where,text=text,command=fn,relief='flat',bd=0,cursor='hand2',
                         bg=TEAL if accent else PANEL2,fg=DARK if accent else INK,
                         activebackground=GOLD,activeforeground=DARK,
                         font=('Segoe UI',10,'bold'),padx=14,pady=10)

    def _shell(self):
        sidebar=tk.Frame(self,bg=SIDE,width=220)
        sidebar.pack(side='left',fill='y'); sidebar.pack_propagate(False)
        self.label(sidebar,'◈ QUESTBRIDGE',18,INK,True).pack(anchor='w',padx=20,pady=(30,4))
        self.label(sidebar,'VR + NATIVE LAB',9,TEAL,True).pack(anchor='w',padx=21,pady=(0,32))
        self.nav={}
        for page,sym in [('Library','▦'),('VR Lab','♧'),('Bridge Monitor','⇄'),('CPU Lab','⌘'),('Input Lab','◉'),('Engine Status','≡')]:
            b=tk.Button(sidebar,text=f'  {sym}   {page}',anchor='w',relief='flat',bd=0,
                        cursor='hand2',font=('Segoe UI',11),bg=SIDE,fg=MUTED,
                        activebackground=PANEL2,activeforeground=INK,padx=16,pady=17,
                        command=lambda p=page:self.show(p))
            b.pack(fill='x',padx=10,pady=2);self.nav[page]=b
        self.label(sidebar,'0.6.0  •  EXPERIMENTAL',9,MUTED).pack(side='bottom',pady=20)
        right=tk.Frame(self,bg=DARK); right.pack(side='left',fill='both',expand=True)
        header=tk.Frame(right,bg=DARK);header.pack(fill='x',padx=28,pady=(27,16))
        self.title_label=self.label(header,'',23,INK,True);self.title_label.pack(side='left')
        self.label(header,'PC / VR • SELECT AFTER IMPORT',9,TEAL,True).pack(side='right',pady=12)
        tk.Frame(right,bg=PANEL2,height=1).pack(fill='x',padx=28)
        footer=tk.Frame(right,bg=SIDE);footer.pack(side='bottom',fill='x')
        tk.Label(footer,textvariable=self.status,bg=SIDE,fg=MUTED,
                 font=('Segoe UI',9)).pack(side='left',padx=20,pady=11)
        self.body=tk.Frame(right,bg=DARK);self.body.pack(fill='both',expand=True,padx=28,pady=23)

    def show(self,page):
        self.page=page;self.title_label.config(text=page)
        for name,b in self.nav.items():b.config(bg=PANEL2 if name==page else SIDE,
                                                 fg=INK if name==page else MUTED)
        for child in self.body.winfo_children():child.destroy()
        self.canvas=None
        {'Library':self._library,'VR Lab':self._vr_lab,'Bridge Monitor':self._bridge_monitor_page,'CPU Lab':self._cpu_lab,
         'Input Lab':self._input_lab,'Engine Status':self._engine_status}[page]()

    def section(self,title,body):
        frame=tk.Frame(self.body,bg=PANEL,padx=20,pady=18)
        frame.pack(fill='x',pady=(0,13))
        self.label(frame,title,15,INK,True).pack(anchor='w')
        self.label(frame,body,10,MUTED,wraplength=670,justify='left').pack(anchor='w',pady=(8,0))
        return frame

    def _library(self):
        intro=self.section('Your Quest APK library',
            '1. Import your APK.  2. Select it.  3. Choose PC or VR when a compatible Quest APK engine is available. '
            'Today you can launch our own PC or VR movement sample below. The launcher opens without SteamVR or a headset.')
        self.button(intro,'+ Import APK',self._import,True).pack(anchor='w',pady=(14,0))
        games=self.store.data.get('games',[])
        if not games:
            self.label(self.body,'No APKs imported yet.',13,MUTED).pack(anchor='w',pady=22)
            return
        frame=tk.Frame(self.body,bg=DARK);frame.pack(fill='both',expand=True)
        lst=tk.Listbox(frame,fg=INK,bg=PANEL,selectbackground=PANEL2,
                       selectforeground=TEAL,relief='flat',borderwidth=0,
                       font=('Segoe UI',11),height=min(len(games)+1,9),exportselection=False)
        lst.pack(fill='x')
        for g in games:
            lst.insert('end',f"{g.get('name','Unknown')}     •     {g.get('engine','Unknown engine')}     •     {', '.join(g.get('abis',[])) or 'No ABI detected'}")
        if self.selected is not None:
            hit=next((i for i,g in enumerate(games) if g['id']==self.selected),0)
            lst.selection_set(hit)
        else:lst.selection_set(0)
        actions=tk.Frame(frame,bg=DARK);actions.pack(fill='x',pady=13)
        def pick():
            selected=lst.curselection()
            if not selected:raise ValueError('Select an APK first')
            return games[selected[0]]
        def inspect():
            try:
                record=pick();self.selected=record['id']
                self._details(record)
            except ValueError as e:messagebox.showwarning('Select an APK',str(e))
        def explain_apk_runtime():
            try: record=pick()
            except ValueError: return
            messagebox.showinfo('Why Play is unavailable',
                f"{record['name']} is imported and ready for compatibility testing, "
                'but QuestBridge does not have a working Android Quest execution engine.\n\n'
                'Play on PC requires Android ARM64/graphics services and keyboard-to-Quest input mapping.\n'
                'Play in VR requires those same services plus an Android OpenXR-to-PC bridge.\n\n'
                'Both Play buttons are disabled until an actual executable game backend exists. '
                'The PC/VR Lab buttons below launch a separate, original test arena.')
        def remove():
            try: record=pick()
            except ValueError: return
            if messagebox.askyesno('Remove imported copy?',f"Remove {record['name']} from QuestBridge's local library?"):
                self.store.remove(record['id']);self.selected=None;self.show('Library')
        self.button(actions,'Inspect APK',inspect,True).pack(side='left',padx=(0,9))
        self.button(actions,'Why not playable?',explain_apk_runtime).pack(side='left',padx=(0,9))
        self.button(actions,'Remove',remove).pack(side='left')
        game_launch=tk.Frame(frame,bg=PANEL,padx=15,pady=13)
        game_launch.pack(fill='x',pady=(3,10))
        self.label(game_launch,'SELECTED APK — GAME LAUNCH',12,INK,True).pack(anchor='w')
        self.label(game_launch,'PC and VR require an Android/Quest runtime. Import succeeds; gameplay is not implemented.',9,GOLD).pack(anchor='w',pady=(5,9))
        controls=tk.Frame(game_launch,bg=PANEL);controls.pack(fill='x')
        for caption in ('Play APK on PC  •  Unavailable','Play APK in VR  •  Unavailable'):
            b=self.button(controls,caption,lambda:None)
            b.config(state='disabled',disabledforeground=MUTED,bg='#283047',cursor='arrow')
            b.pack(side='left',padx=(0,9))
        self.label(frame,'Want to test movement now? Open VR Lab → launch PC or SteamVR sample (not the imported APK).',10,TEAL).pack(anchor='w',pady=6)

    def _vr_lab(self):
        info=self.section('REAL OpenXR VR arena + local input/scene bridge',
            'Choose desktop first or VR when your Quest 3S is connected through SteamVR. '
            'Unlike the old shortcut, opening the launcher does NOT initialize OpenXR. '
            'WASD moves the viewpoint in either mode (the game window needs keyboard focus). '
            'A local Python host now receives real pose/WASD packets from Godot and controls a scene object. Not an Android APK emulator yet.')
        launch_controls=tk.Frame(info,bg=PANEL)
        launch_controls.pack(anchor='w',pady=(15,0))
        self.button(launch_controls,'Play PC sample  •  WASD',lambda:self._launch_vr('desktop'),True).pack(side='left',padx=(0,10))
        self.button(launch_controls,'Play VR sample  •  SteamVR',lambda:self._launch_vr('vr')).pack(side='left')
        self.label(info,'Both buttons start our OWN test arena. They do not execute your imported APK.',9,GOLD).pack(anchor='w',pady=(10,2))
        godot=find_godot()
        self.label(info,'Godot engine: '+(str(godot) if godot else 'Not detected — copy Godot 4 EXE beside QuestBridge'),
                   10,TEAL if godot else GOLD).pack(anchor='w',pady=(14,4))
        self.label(info,vr_runtime_summary(),10,MUTED,wraplength=700,justify='left').pack(anchor='w')
        self.section('Keyboard controls',
            'W / A / S / D  —  forward / left / backward / right (relative to where you look)\n'
            'Shift  —  sprint\nF  —  toggle fly\nSpace / Ctrl  —  up / down when flying\n'
            'N  —  toggle noclip through the test arena walls\n'
            'Mouse  —  look around in desktop mode (real headset tracking in VR)\n'
            'Esc  —  release mouse in desktop mode')
        self.section('Why your imported APK will not automatically play',
            'SteamVR can render a Windows OpenXR game but it does not run Android Quest APK binaries. '
            'Imported APKs require a real Android ARM64 runtime, Meta-compatible services and '
            'graphics/OpenXR translation. We have not implemented these yet. '
            'VR Lab shows a real first-step demonstration; it does not claim to launch your APK.')

    def _launch_vr(self, mode='desktop'):
        try:
            host = self._ensure_bridge()
            process=launch_vr_lab(mode=mode, bridge_port=host.port, bridge_token=host.token)
            self.status.set(f'{mode.upper()} sample started (PID {process.pid}) • host bridge UDP:{host.port} • not imported APK')
            if mode=='vr':
                messagebox.showinfo('VR test scene launching',
                    'SteamVR must be the active OpenXR runtime and your headset must be connected.\n'
                    'Only NOW has QuestBridge requested OpenXR.\n'
                    'A localhost bridge receives tracking and sends ball positions back.\n\n'
                    'This launches our own VR sample—not the selected APK.')
            else:
                messagebox.showinfo('Desktop test scene launching',
                    'Our original 3D sample is launching with OpenXR disabled.\n'
                    'Click its window and use WASD + mouse to move.\n'
                    'Check the Bridge Monitor tab to view live tracking packets.\n\n'
                    'This launches our own PC sample—not the selected APK.')
        except (FileNotFoundError, OSError, ValueError) as exc:
            self.status.set('PC/VR lab requires Godot 4.3+; VR also requires SteamVR and headset')
            messagebox.showwarning('Missing requirement',
                str(exc)+'\n\nGet Godot from https://godotengine.org/download/windows/')

    def _ensure_bridge(self) -> BridgeServer:
        if self.bridge is None or not self.bridge.snapshot().running:
            self.bridge = BridgeServer().start()
        return self.bridge

    def _bridge_monitor_page(self):
        frame=self.section('LOCAL VR TRACKING + SCENE BRIDGE  •  REAL UDP TRANSPORT',
            'This is our first live runtime subsystem: the Godot PC/VR scene sends headset position, '
            'controller positions and WASD state to our Python host. The Python host sends a moving '
            'ball back to Godot. It uses local port 127.0.0.1 only and no ADB or Refract. '
            'Actual Android Quest game execution still needs Android services and OpenXR translation.')
        self.bridge_monitor=self.label(frame,'Bridge not started',12,TEAL,True)
        self.bridge_monitor.pack(anchor='w',pady=(16,8))
        bar=tk.Frame(frame,bg=PANEL);bar.pack(anchor='w')
        self.button(bar,'Start bridge',self._start_bridge_ui,True).pack(side='left',padx=(0,9))
        self.button(bar,'Test live UDP exchange',self._probe_bridge_ui).pack(side='left',padx=(0,9))
        self.button(bar,'Stop bridge',self._stop_bridge_ui).pack(side='left')
        self.section('How to see the connection work',
            '1. Open VR Lab and start Play PC sample or Play VR sample.\n'
            '2. Return here to watch packets and your live headset/WASD position.\n'
            '3. The golden sphere in Godot should move according to data sent BACK from Python.\n'
            '4. Without Godot, click Test live UDP exchange to verify a real client-server round trip.\n'
            'This transport can later be connected to an Android XR guest adapter; it is not one yet.')
        self._update_bridge_monitor()

    def _start_bridge_ui(self):
        host=self._ensure_bridge()
        self.status.set(f'Local XR pose bridge listening on 127.0.0.1:{host.port}')
        self._update_bridge_monitor()

    def _probe_bridge_ui(self):
        try:
            host=self._ensure_bridge()
            result=probe_bridge(host)
            self.status.set(f'UDP bridge exchanged a pose and world update • frame {result["frames"]}')
            self._update_bridge_monitor()
            messagebox.showinfo('Real bridge round trip passed',
                'Sent a real pose packet over UDP to the Python host.\n'
                f'Received server-authored ball coordinates: {result["ball"]}\n\n'
                'This tests the transport but does NOT execute an APK.')
        except (OSError, ValueError) as exc:
            messagebox.showerror('Bridge test failed',str(exc))

    def _stop_bridge_ui(self):
        if self.bridge is not None:
            self.bridge.close()
            self.bridge=None
        self.status.set('Local VR bridge stopped')
        self._update_bridge_monitor()

    def _update_bridge_monitor(self):
        if self.page != 'Bridge Monitor' or self.bridge_monitor is None:
            return
        if self.bridge is None:
            self.bridge_monitor.config(text='OFFLINE • Start bridge, or launch a sample from VR Lab',fg=GOLD)
            return
        snapshot=self.bridge.snapshot()
        position=', '.join(f'{n:+.2f}' for n in snapshot.head)
        state='CONNECTED' if snapshot.connected else 'LISTENING'
        self.bridge_monitor.config(text=
            f'{state}  •  127.0.0.1:{snapshot.port}  •  Frames received: {snapshot.frames}\n'
            f'Runtime: {snapshot.mode}  •  Head XYZ: {position}  •  WASD active: {snapshot.has_wasd}\n'
            f'Last packet age: {snapshot.age_seconds:.1f}s' if snapshot.age_seconds is not None else
            f'{state}  •  127.0.0.1:{snapshot.port}  •  Waiting for first packet',
            fg=TEAL if snapshot.connected else GOLD)

    def _close(self):
        if self.bridge is not None:
            self.bridge.close()
        self.destroy()

    def _import(self):
        path=filedialog.askopenfilename(title='Import a Quest APK',filetypes=[('Android APK','*.apk')])
        if not path:return
        self.status.set('Importing and inspecting APK...')
        try:
            record=self.store.import_apk(path)
            self.selected=record['id'];self.status.set(f"Imported {record['name']}")
            self.show('Library')
            self._details(record)
        except Exception as e:
            self.status.set('APK import failed')
            messagebox.showerror('Import failed',str(e))

    def _details(self,record):
        win=tk.Toplevel(self);win.title('APK properties — '+record['name'])
        win.geometry('700x510');win.configure(bg=DARK)
        data={k:v for k,v in record.items() if k not in ('path',)}
        field=tk.Text(win,bg=PANEL,fg=INK,insertbackground=INK,wrap='word',
                      relief='flat',font=('Consolas',10),padx=15,pady=15)
        field.pack(fill='both',expand=True,padx=15,pady=15)
        field.insert('1.0',json.dumps(data,indent=2,ensure_ascii=False))
        field.config(state='disabled')

    def _cpu_lab(self):
        top=self.section('Our original ARM64 interpreter',
            'This is real instruction interpretation written specifically for QuestBridge, '
            'running a tiny synthetic AArch64 program. It is NOT an Android OS, '
            'game execution or an emulator capable of launching a Quest APK.')
        self.button(top,'Run ARM64 sample program',self._run_demo,True).pack(anchor='w',pady=(14,0))
        self.output=tk.Text(self.body,bg=PANEL,fg=TEAL,insertbackground=TEAL,
                            wrap='none',relief='flat',font=('Consolas',11),padx=18,pady=15)
        self.output.pack(fill='both',expand=True)
        self.output.insert('1.0','Click “Run ARM64 sample program” to execute ARM instructions.\n\n'
                           'Supported instructions: MOVZ, ADD immediate, SUB immediate, B, NOP, RET.\n'
                           'Result should be X0 = 12 and X1 = 3.\n')
        self.output.config(state='disabled')

    def _run_demo(self):
        result=demo_trace()
        contents='QUESTBRIDGE ARM64 MICROCORE\n'+'='*56+'\n\n'+'\n'.join(result['trace'])
        contents+=f"\n\nRESULT: X0 = {result['x0']}, X1 = {result['x1']}\nInstructions executed: {result['steps']}\n\n"
        contents+='No external runtime, no Refract, no ADB.\n'
        self.output.config(state='normal');self.output.delete('1.0','end')
        self.output.insert('1.0',contents);self.output.config(state='disabled')
        self.status.set('Original ARM64 interpreter executed its sample successfully')

    def _input_lab(self):
        box=self.section('WASD input sandbox',
            'Test potential desktop movement controls in our OWN scene. '
            'WASD move • Shift sprint • F flight • N noclip • E snap a test ball. '
            'This is not connected to any APK or multiplayer game.')
        self.mode_label=self.label(box,'Fly OFF   •   Noclip OFF',10,TEAL,True)
        self.mode_label.pack(anchor='w',pady=(13,0))
        self.canvas=tk.Canvas(self.body,bg='#0f1d2e',highlightthickness=0)
        self.canvas.pack(fill='both',expand=True)
        self.canvas.bind('<Button-1>',lambda e:self.canvas.focus_set())
        self.canvas.focus_set()
        self._draw()

    def _draw(self):
        c=self.canvas
        if not c:return
        c.delete('all'); w=max(c.winfo_width(),700);h=max(c.winfo_height(),300)
        for x in range(0,w,38):c.create_line(x,0,x,h,fill='#183047')
        for y in range(0,h,38):c.create_line(0,y,w,y,fill='#183047')
        c.create_rectangle(275,85,335,255,fill='#4b5c72',outline='#c4cfda',width=2)
        x,y=self.pos;bx,by=self.ball
        c.create_oval(bx-15,by-15,bx+15,by+15,fill=GOLD,outline='#fff2c7',width=2)
        c.create_oval(x-17,y-17,x+17,y+17,fill=TEAL,outline='#dcfffa',width=2)
        c.create_text(14,14,anchor='nw',fill=MUTED,font=('Segoe UI',10),
                      text='Blue-green = player   •   Gold = ball   •   Gray = blocking wall')
        c.create_text(14,35,anchor='nw',fill=GOLD,font=('Segoe UI',10),
                      text='Fly is a simulated toggle; noclip enables passing through the test wall')

    def _press(self,event):
        key=event.keysym.lower()
        if self.page=='Input Lab':
            if key not in self.held:
                if key=='f':self.fly=not self.fly
                if key=='n':self.noclip=not self.noclip
                if key=='e':self.ball=self.pos.copy()
            self.held.add(key)
            self.mode_label.config(text=f"Fly {'ON' if self.fly else 'OFF'}   •   Noclip {'ON' if self.noclip else 'OFF'}")
    def _release(self,event):self.held.discard(event.keysym.lower())

    def _tick(self):
        if self.page == 'Bridge Monitor':
            self._update_bridge_monitor()
        if self.page=='Input Lab' and self.canvas is not None:
            dx=int('d' in self.held)-int('a' in self.held)
            dy=int('s' in self.held)-int('w' in self.held)
            if dx or dy:
                factor=(8 if ('shift_l' in self.held or 'shift_r' in self.held) else 4)/math.hypot(dx,dy)
                x,y=self.pos;nx=x+dx*factor;ny=y+dy*factor
                w=max(self.canvas.winfo_width(),700);h=max(self.canvas.winfo_height(),300)
                nx=max(18,min(w-18,nx));ny=max(18,min(h-18,ny))
                hit=(258<nx<352 and 68<ny<272)
                if self.noclip or not hit:self.pos=[nx,ny]
            self._draw()
        self.after(40,self._tick)

    def _engine_status(self):
        self.section('Independent emulator architecture',
            'This project contains no Refract code, executable, integration or dependency. '
            'The Android SDK and Meta Quest Link are not required for current features.')
        items=[
            ('APK import / structure analysis','WORKING',TEAL),
            ('Local storage and metadata','WORKING',TEAL),
            ('Original ARM64 instruction subset','PROTOTYPE',GOLD),
            ('Desktop keyboard control sandbox','WORKING (sandbox only)',TEAL),
            ('ARM64 ELF loader and dynamic linker','NOT IMPLEMENTED',BAD),
            ('Android kernel/system-service compatibility','NOT IMPLEMENTED',BAD),
            ('Android app lifecycle / Java runtime','NOT IMPLEMENTED',BAD),
            ('Vulkan / OpenGL ES graphics translation','NOT IMPLEMENTED',BAD),
            ('OpenXR → SteamVR arena (on-demand only)','SOURCE READY • TEST ON WINDOWS',GOLD),
            ('Keyboard locomotion inside native VR scene','SOURCE READY • TEST ON WINDOWS',GOLD),
            ('Native VR scene ⇄ Python host (UDP pose/world bridge)','IMPLEMENTED • TEST ON YOUR PC',TEAL),
            ('Quest platform APIs, authentication and multiplayer','NOT IMPLEMENTED',BAD),
            ('Launch imported Quest APKs on Windows or VR','NOT IMPLEMENTED • BUTTONS DISABLED',BAD),
        ]
        outer=tk.Frame(self.body,bg=PANEL,padx=16,pady=11);outer.pack(fill='both',expand=True)
        for title,status,col in items:
            row=tk.Frame(outer,bg=PANEL);row.pack(fill='x',pady=8)
            self.label(row,title,10,INK).pack(side='left')
            self.label(row,status,9,col,True).pack(side='right')
        self.label(self.body,'Engineering rule: never claim an APK works until it actually launches and renders.',10,GOLD).pack(anchor='w',pady=12)
