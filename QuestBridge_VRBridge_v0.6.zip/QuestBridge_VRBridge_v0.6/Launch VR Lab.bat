@echo off
cd /d "%~dp0"
echo Opening QuestBridge launcher first. Choose PC or VR AFTER opening the app.
call "Start QuestBridge VR.bat"
