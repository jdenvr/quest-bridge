@echo off
cd /d "%~dp0"
call "Start QuestBridge VR.bat"
