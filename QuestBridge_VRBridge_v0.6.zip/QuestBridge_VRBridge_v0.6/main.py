"""QuestBridge Native: independent prototype. Not a runnable Quest APK emulator."""
from __future__ import annotations
import argparse
import json
from questbridge.apk import analyze_apk
from questbridge.arm64 import demo_trace

def main():
    parser = argparse.ArgumentParser(description='QuestBridge Native alpha (no external backend)')
    parser.add_argument('--inspect', metavar='GAME.apk', help='Inspect APK without executing it')
    parser.add_argument('--cpu-demo', action='store_true', help='Run our original ARM64 interpreter')
    args = parser.parse_args()
    if args.inspect:
        print(json.dumps(analyze_apk(args.inspect).as_dict(), indent=2))
    elif args.cpu_demo:
        print(json.dumps(demo_trace(), indent=2))
    else:
        from questbridge.gui import QuestBridge
        QuestBridge().mainloop()

if __name__ == '__main__':
    main()
